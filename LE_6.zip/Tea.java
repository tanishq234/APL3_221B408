class Tea extends Offering{
    String getName(){
        return "Tea ";
    }
    int getPrice(){
        return 25;
    }
}