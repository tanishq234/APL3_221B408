abstract class Offering{
    abstract String getName();
    abstract int getPrice();
}