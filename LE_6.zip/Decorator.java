abstract class Decorator extends Offering{
    Offering offer;
}